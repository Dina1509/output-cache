				README
			NOutput Cache Sample

===============================================================================
			NCACHE FEATURES USED
===============================================================================
This sample deals with the following feature of NCache.
	i)	output caching 
	
===============================================================================
  			      Introduction
===============================================================================
This sample application is based on NCache output caching feature. It helps you 
understand the use of output caching features of NCache.

===============================================================================
			      Description
===============================================================================
NCache provides extremely fast and reliable output caching feature for your 
ASP.NET applications running in web farm environment, where regular output caching
fails.
When user run this sample first time the data will be loaded from the database, 
and the data is also stored to the cache the user specified in the web.config of
the applicationbut. Next time when user requests that page the data is loaded from
cache insted of the database.
The user can check the no of items in the cache by checking the statistics of the 
cache from NCache Manager or checking the cache count of cache by getcachecount 
Cmd tool.  

===============================================================================
                           How To Run This Sample
===============================================================================
By default three caches namely, 'myCache', 'myPartitionedCache' and 'myReplicatedCache'
are registered on your system upon the installation of NCache. You may use any of
these caches with this sample. By default 'myCache' is given as the cache name in 
web.config file. The user can change it from web.config.  

===============================================================================
			     NCache Settings
===============================================================================
To use this sample application with NCache the user have to start the cache that 
he specified in the web.config file. Cache can be strated by using start cmd toll
or from NCacheManager.
									
======================================================================================
The NCache(TM) is a product of Alachisoft(TM), Inc.
Copyright� 2014 Alachisoft, Inc.
All rights reserved.